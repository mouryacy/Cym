export default function Features() {
  const features = [
    { title: "Blazing fast", text: "Next.js 14 App Router with optimized builds." },
    { title: "Beautiful UI", text: "Tailwind CSS with elegant defaults and components." },
    { title: "SEO-ready", text: "Metadata, semantic HTML, and great performance." },
    { title: "Deploy in minutes", text: "Vercel and Netlify friendly out of the box." },
    { title: "TypeScript", text: "Strict enough to help, flexible enough to move quickly." },
    { title: "Extensible", text: "Add pages, APIs, and integrations as you grow." }
  ];
  return (
    <div id="features" className="grid md:grid-cols-3 gap-6">
      {features.map((f) => (
        <div key={f.title} className="card">
          <h3 className="text-lg font-semibold">{f.title}</h3>
          <p className="mt-2 text-slate-600">{f.text}</p>
        </div>
      ))}
    </div>
  )
}
