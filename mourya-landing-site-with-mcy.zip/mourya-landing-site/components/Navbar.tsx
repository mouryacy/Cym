export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 backdrop-blur bg-white/70 border-b border-slate-200">
      <div className="container flex items-center justify-between py-4">
        <a href="/" className="flex items-center gap-2 font-semibold">
          <span className="h-8 w-8 rounded-xl bg-brand inline-flex items-center justify-center text-white">M</span>
          <span>MCY Studios</span>
        </a>
        <nav className="hidden md:flex items-center gap-6 text-sm text-slate-700">
          <a href="#features" className="hover:text-slate-900">Features</a>
          <a href="#contact" className="hover:text-slate-900">Contact</a>
          <a href="https://vercel.com/new" className="btn btn-ghost">Deploy</a>
        </nav>
      </div>
    </header>
  );
}
