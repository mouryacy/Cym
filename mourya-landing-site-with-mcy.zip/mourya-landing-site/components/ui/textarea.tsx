import * as React from "react";
import { cn } from "@/components/lib/utils";

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, ...props }, ref) => (
    <textarea
      ref={ref}
      className={cn(
        "w-full rounded-md border px-3 py-2 text-sm outline-none ring-0 focus:border-slate-400",
        className
      )}
      {...props}
    />
  )
);
Textarea.displayName = "Textarea";
