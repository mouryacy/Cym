import { ArrowRight, Sparkles } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-brand/10 to-transparent pointer-events-none" />
      <div className="container py-20 md:py-28">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-brand-light px-3 py-1 text-sm text-brand">
              <Sparkles className="w-4 h-4" /> Fresh Next.js 14 Template
            </div>
            <h1 className="mt-4 text-4xl md:text-6xl font-bold leading-tight">
              Build a beautiful site <span className="text-brand">fast</span>.
            </h1>
            <p className="mt-4 text-lg text-slate-600">
              Production-grade template with Tailwind CSS, responsive layout, and clean components.
            </p>
            <div className="mt-6 flex items-center gap-3">
              <a href="#contact" className="btn btn-primary">
                Start your project <ArrowRight className="w-4 h-4" />
              </a>
              <a href="#features" className="btn btn-ghost">See features</a>
            </div>
          </div>
          <div className="relative">
            <div className="card">
              <div className="aspect-video rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-500">
                Responsive preview
              </div>
              <ul className="mt-6 grid grid-cols-2 gap-3 text-sm">
                <li className="rounded-xl border p-3">⚡ Fast by default</li>
                <li className="rounded-xl border p-3">📱 Mobile-first</li>
                <li className="rounded-xl border p-3">🧩 Reusable UI</li>
                <li className="rounded-xl border p-3">🚀 1-click deploy</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
