# MCY Studios — Next.js 14 Landing Site

A sleek, mobile-first landing page built with Next.js 14 (App Router) and Tailwind CSS.

## 🚀 Quick start

```bash
# 1) Install dependencies
npm install

# 2) Run locally
npm run dev

# 3) Build & run production
npm run build && npm start
```

## ☁️ Deploy to Vercel

1. Create a new GitHub repository and push these files.
2. Go to Vercel → **New Project** → import your repo.
3. Framework preset: **Next.js**. You can keep all defaults.
4. Click **Deploy**. That's it.

## 🔧 Customize

- Edit `app/page.tsx` and files in `components/` to change content.
- Update theme colors in `tailwind.config.js`.
- Replace the logo/graphics in `public/`.
