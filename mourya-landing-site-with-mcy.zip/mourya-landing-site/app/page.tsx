'use client'

import { useState } from "react";
import { Menu, X, Rocket, Palette, Phone, Mail, MapPin, ArrowRight, CheckCircle2, Images, Users, Bot, Send, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

// Theme
const THEME = {
  primary: "#C6BEB5",
  accent: "#4A3728",
  bg: "#F8F7F5",
  text: "#333333",
  black: "#1C1C1C",
};

// Optional: plug your project image URLs here
const PROJECTS = [
  { src: "", title: "Executive Office — Marble & Walnut", tag: "Interiors" },
  { src: "", title: "Feature Wall — Stone Relief", tag: "Interiors" },
  { src: "", title: "Garden‑side Lounge", tag: "Residential" },
  { src: "", title: "Contemporary Living — Media Wall", tag: "Residential" },
  { src: "", title: "Primary Bedroom — Monochrome Wardrobe", tag: "Residential" },
  { src: "", title: "Pooja Niche — Timber & Light", tag: "Residential" },
  { src: "", title: "Courtyard Screen & Glazing", tag: "Residential" },
];

export default function Page() {
  const [open, setOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  return (
    <div className="min-h-screen" style={{ backgroundColor: THEME.bg, color: THEME.text }}>
      {/* Top bar */}
      <header className="sticky top-0 z-40 w-full border-b backdrop-blur" style={{ backgroundColor: "rgba(248,247,245,0.9)", borderColor: THEME.primary }}>
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="#home" className="flex items-center gap-2 font-semibold" style={{ color: THEME.black }}>
            <div className="h-8 w-8 rounded-xl bg-slate-900" />
            <span className="tracking-tight">MCY STUDIOS</span>
          </a>
          <nav className="hidden items-center gap-6 md:flex">
            <a href="#services" className="hover:text-slate-900">Services</a>
            <a href="#work" className="hover:text-slate-900">Work</a>
            <a href="#about" className="hover:text-slate-900">About</a>
            <a href="#contact" className="hover:text-slate-900">Contact</a>
            <Button className="rounded-2xl" style={{ backgroundColor: THEME.accent, borderColor: THEME.accent }}>Get a quote</Button>
          </nav>
          <button className="md:hidden" aria-label="Open menu" onClick={() => setOpen(true)}>
            <Menu />
          </button>
        </div>
        {/* Mobile menu */}
        {open && (
          <div className="md:hidden border-t">
            <div className="mx-auto max-w-6xl px-4 py-4">
              <div className="flex items-center justify-between pb-3">
                <span className="font-semibold">Menu</span>
                <button aria-label="Close menu" onClick={() => setOpen(false)}><X /></button>
              </div>
              <div className="grid gap-2">
                <a onClick={() => setOpen(false)} href="#services" className="py-2">Services</a>
                <a onClick={() => setOpen(false)} href="#work" className="py-2">Work</a>
                <a onClick={() => setOpen(false)} href="#about" className="py-2">About</a>
                <a onClick={() => setOpen(false)} href="#contact" className="py-2">Contact</a>
                <Button className="mt-2 w-full rounded-2xl">Get a quote</Button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero */}
      <section id="home" className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10" style={{background:`linear-gradient(180deg, ${THEME.bg}, #ffffff)`}} />
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2 md:py-24">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border px-3 py-1 text-sm text-slate-600">
              <Rocket className="h-4 w-4" /> Architecture & Urban Design
            </div>
            <h1 className="mt-4 text-4xl font-extrabold tracking-tight md:text-5xl font-serif" style={{ color: THEME.black }}>
              Designing dreams. Building future.
            </h1>
            <p className="mt-4 text-lg text-slate-600">
              We plan, design, and deliver timeless architecture — from concept sketches to permit sets, BIM coordination, and construction administration.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Button className="rounded-2xl" style={{ backgroundColor: THEME.accent, borderColor: THEME.accent }}>
                Book a consultation <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <a href="#work" className="inline-flex items-center gap-2 text-slate-700 hover:text-slate-900">
                View portfolio <Images className="h-4 w-4" />
              </a>
            </div>
            <ul className="mt-6 grid gap-2 text-sm text-slate-600">
              {[
                "Full architectural services",
                "BIM‑ready deliverables",
                "Fast feasibility studies",
              ].map((t) => (
                <li key={t} className="inline-flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> {t}</li>
              ))}
            </ul>
          </div>
          <div className="relative">
            <div className="aspect-[16/10] w-full overflow-hidden rounded-2xl border bg-slate-100 shadow-sm">
              {/* Replace with your hero image */}
              <div className="flex h-full items-center justify-center text-slate-400">Hero Image</div>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="" style={{ backgroundColor: "#F5F3F0" }}>
        <div className="mx-auto max-w-6xl px-4 py-16">
          <div className="flex items-end justify-between gap-4">
            <h2 className="text-3xl font-bold tracking-tight font-serif" style={{ color: THEME.black }}>Services</h2>
            <a href="#contact" className="text-sm text-slate-600 hover:text-slate-900">Talk to us →</a>
          </div>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {[
              { icon: <Palette />, title: "Architecture", desc: "Residential, commercial, and adaptive reuse." },
              { icon: <Images />, title: "Interiors & Visualization", desc: "Material palettes, 3D renders, animations." },
              { icon: <Phone />, title: "Project Delivery", desc: "BIM, permitting, and construction admin." },
            ].map((c) => (
              <Card key={c.title} className="rounded-2xl" style={{ borderColor: THEME.primary }}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-xl">
                    <span className="grid h-10 w-10 place-items-center rounded-xl bg-white shadow-sm">{c.icon}</span>
                    {c.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-slate-600">{c.desc}</CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Work */}
      <section id="work" className="">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-3xl font-bold tracking-tight font-serif" style={{ color: THEME.black }}>Built & imagined work</h2>
          <p className="mt-2 text-slate-600">A calm, restrained gallery to reflect MCY’s interiors and architecture.</p>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {PROJECTS.map((p, i) => (
              <div key={i} className="group overflow-hidden rounded-2xl border bg-white shadow-sm" style={{ borderColor: THEME.primary }}>
                <div className="aspect-[4/3] w-full bg-slate-100">
                  {p.src ? (
                    <img src={p.src} alt={p.title} className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full items-center justify-center text-slate-400">Add image URL in PROJECTS[{i}].src</div>
                  )}
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">{p.title}</h3>
                    <span className="text-xs text-slate-500">{p.tag}</span>
                  </div>
                  <p className="mt-1 text-sm text-slate-600">High‑end materials, serene palettes, and precise detailing.</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="" style={{ backgroundColor: "#F5F3F0" }}>
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2">
          <div className="order-2 md:order-1">
            <h2 className="text-3xl font-bold tracking-tight font-serif" style={{ color: THEME.black }}>About MCY Studios</h2>
            <p className="mt-3 text-slate-600">
              MCY Studios is a multidisciplinary architectural firm crafting human‑centered spaces. We combine rigorous technical delivery with a design-first approach, using BIM and computational tools to reduce risk and accelerate schedules.
            </p>
            <ul className="mt-6 grid gap-2 text-sm text-slate-600">
              {["Architecture + Interiors + Planning", "BIM / Revit / Navisworks", "Sustainability & energy modeling"].map(b => (
                <li key={b} className="inline-flex items-center gap-2"><Users className="h-4 w-4" /> {b}</li>
              ))}
            </ul>
          </div>
          <div className="order-1 md:order-2">
            <div className="aspect-[4/3] w-full overflow-hidden rounded-2xl border bg-slate-100 shadow-sm" />
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-3xl font-bold tracking-tight font-serif" style={{ color: THEME.black }}>Engagement models</h2>
          <p className="mt-2 text-slate-600">Choose the level of engagement that fits your project size and timeline.</p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {["Consultation", "Concept to Permit", "Full Service"].map((tier, idx) => (
              <Card key={tier} className={`rounded-2xl ${idx===1?"shadow-md":""}`} style={{ borderColor: THEME.primary }}>
                <CardHeader>
                  <CardTitle>{tier}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-extrabold">${idx===0?"/hr":idx===1?"Fixed":"% of construction"}</div>
                  <ul className="mt-4 grid gap-2 text-sm text-slate-600">
                    {[
                      "Site visit & briefing",
                      "Zoning / code review",
                      "Concept options & massing",
                      "Schedule & budget guidance",
                    ].map(f => (
                      <li key={f} className="inline-flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> {f}</li>
                    ))}
                  </ul>
                  <Button className="mt-6 w-full rounded-2xl">Choose {tier}</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="" style={{ backgroundColor: "#F5F3F0" }}>
        <div className="mx-auto max-w-6xl px-4 py-16">
          <div className="grid gap-8 md:grid-cols-3">
            <div className="md:col-span-1">
              <h2 className="text-3xl font-bold tracking-tight font-serif" style={{ color: THEME.black }}>Get in touch</h2>
              <p className="mt-2 text-slate-600">We’ll get back within one business day.</p>
              <div className="mt-6 grid gap-3 text-sm text-slate-700">
                <div className="inline-flex items-center gap-2"><Mail className="h-4 w-4" /> hello@example.com</div>
                <div className="inline-flex items-center gap-2"><Phone className="h-4 w-4" /> (555) 000-1234</div>
                <div className="inline-flex items-center gap-2"><MapPin className="h-4 w-4" /> Your City, ST</div>
              </div>
            </div>
            <Card className="md:col-span-2 rounded-2xl">
              <CardContent className="p-6">
                <form className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="col-span-1">
                    <label className="text-sm">Name</label>
                    <Input placeholder="Your name" />
                  </div>
                  <div className="col-span-1">
                    <label className="text-sm">Email</label>
                    <Input type="email" placeholder="you@example.com" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm">Message</label>
                    <Textarea placeholder="Tell us about your project..." rows={5} />
                  </div>
                  <div className="md:col-span-2">
                    <Button type="button" className="w-full rounded-2xl">Send message</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t" style={{ backgroundColor: THEME.bg, borderColor: THEME.primary }}>
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 md:flex-row">
          <p className="text-sm text-slate-500">© {new Date().getFullYear()} MCY Studios. All rights reserved.</p>
          <div className="flex items-center gap-4 text-sm text-slate-600">
            <a href="#" className="hover:text-slate-900">Privacy</a>
            <a href="#" className="hover:text-slate-900">Terms</a>
          </div>
        </div>
      </footer>

      {/* AI Interactive Interface */}
      <button
        onClick={() => setAiOpen(!aiOpen)}
        className="fixed bottom-6 right-6 z-50 inline-flex items-center gap-2 rounded-2xl border px-4 py-2 shadow-lg backdrop-blur hover:opacity-95" style={{ backgroundColor: THEME.bg, borderColor: THEME.primary, color: THEME.black }}
        aria-expanded={aiOpen}
        aria-controls="mcy-ai-panel"
      >
        <Bot className="h-4 w-4" /> MCY AI Studio Assistant — calm mode
      </button>
      {aiOpen && (
        <div id="mcy-ai-panel" className="fixed bottom-24 right-6 z-50 w-[min(420px,90vw)] overflow-hidden rounded-2xl border bg-white shadow-2xl">
          <div className="flex items-center justify-between border-b px-4 py-3">
            <div className="flex items-center gap-2 font-semibold"><Bot className="h-4 w-4" /> Ask about your project</div>
            <button aria-label="Close" onClick={() => setAiOpen(false)}><X className="h-4 w-4" /></button>
          </div>
          <div className="max-h-80 space-y-3 overflow-y-auto p-4 text-sm text-slate-700">
            <div className="inline-flex items-start gap-2"><MessageSquare className="mt-1 h-4 w-4" /> Try: “Can I add a 2nd story on a 50×120 lot in Atlanta?”</div>
            <div className="inline-flex items-start gap-2"><MessageSquare className="mt-1 h-4 w-4" /> Try: “Estimate area and budget for a 3‑bed, 2.5‑bath modern home.”</div>
            <div className="inline-flex items-start gap-2"><MessageSquare className="mt-1 h-4 w-4" /> Try: “Create a zoning checklist and permit timeline.”</div>
          </div>
          <div className="border-t p-3">
            <form className="flex items-center gap-2">
              <Input className="flex-1" placeholder="Type your question… (mock demo)" />
              <Button type="button" className="rounded-2xl"><Send className="mr-2 h-4 w-4" /> Send</Button>
            </form>
            <p className="mt-2 text-xs text-slate-500">This is a UI preview. We can wire it to a real backend or AI later.</p>
          </div>
        </div>
      )}
    </div>
  );
}
